from slam_engine.tecc_model import rag_lookup

print("\n=== Testing RAG Lookup ===")

result = rag_lookup("EXIT")

print("\nRAG OUTPUT:\n", result)
