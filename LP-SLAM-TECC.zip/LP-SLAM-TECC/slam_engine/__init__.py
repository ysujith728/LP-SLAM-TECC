# slam_engine/__init__.py
# package marker, keep empty
